package ex.url;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class URLEx02 {

	public static void main(String[] args) throws IOException {
		URL url = new URL("https://news.naver.com/"); 
		InputStream input = url.openStream(); 
		int readByte; 
		System.out.println("=== 문서의 내용 ==="); 
		while (((readByte = input.read()) != -1)) { 
			System.out.print((char) readByte); 
		} 
		input.close(); 

	}

}
