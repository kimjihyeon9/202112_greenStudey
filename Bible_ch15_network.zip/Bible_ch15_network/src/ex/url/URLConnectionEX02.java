package ex.url;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class URLConnectionEX02 {

	public static void main(String[] args) throws MalformedURLException, IOException {
		URLConnection urlCon = new URL("https://news.naver.com/").openConnection();
		InputStream input = urlCon.getInputStream(); 
		DataInputStream dis = new DataInputStream(input);
		
		int data = 0;
		while((data=dis.read()) != -1) {
			System.out.print((char)data);
		}
	}
}
