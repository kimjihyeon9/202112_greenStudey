package ex.json;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Label;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class ExUrlJson02 extends JFrame implements Runnable {
	private List<ImageIcon> imgIconList = new ArrayList();
	private List<JLabel> labelList = new ArrayList();
	JSONArray jsonArr;
	public static final int SIZE = 16;

	JPanel northPane = new JPanel();
	JPanel centerPane = new JPanel(new GridLayout(4, 4, 5, 5));
	JLabel statusLbl = new JLabel("status ... ");
	Container contentPane;

	{
		for (int i = 0; i<SIZE; i++) {
			ImageIcon icon = new ImageIcon();
			imgIconList.add(icon);
			labelList.add(new JLabel(icon));
		}
	}

	public void loadThumbnailUrlList(String urlPath) {
		statusLbl.setText("loadThumbnailUrlList");
		try {
			URL jsonUrl = new URL(urlPath);
			JSONTokener jtk = new JSONTokener(jsonUrl.openStream());
			jsonArr = new JSONArray(jtk);
			imgIconList = new ArrayList();
			for (int i = 0; i<SIZE; i++) {
				JSONObject jsonObj = jsonArr.getJSONObject(i);
				String thumbnailUrl = jsonObj.getString("thumbnailUrl");
				imgIconList.add(new ImageIcon(new URL(thumbnailUrl)));
				statusLbl.setText("이미지 로딩 중 : " + thumbnailUrl);
				labelList.get(i).setIcon(imgIconList.get(i));
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ExUrlJson02() {
		contentPane = getContentPane();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(800, 600);
		
		contentPane.add(BorderLayout.NORTH, northPane);
		northPane.add(statusLbl);

		contentPane.add(new JScrollPane(centerPane));
		for (int i = 0; i<SIZE; i++) {
			centerPane.add(labelList.get(i));
		}
		statusLbl.setText("main end!!");
		
		// SWING 프레임에 콤포넌트를 모두 그린 후 이미지를 로드 한다.
		// 이미지를 로드하면서 콤포넌트를 붙여 나가는것은 바로 가능 하지 않다.
		new Thread(this).start();
	}

	public static void main(String[] args) {
		new ExUrlJson02().setVisible(true);
	} 

	@Override
	public void run() {
		loadThumbnailUrlList("https://jsonplaceholder.typicode.com/photos");
		statusLbl.setText("Finished!");
	}
}
