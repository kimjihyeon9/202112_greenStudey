package ex.json;

import java.io.IOException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class ExUrlJson {

	public static void main(String[] args) throws IOException {
		URL jsonUrl = new URL("https://jsonplaceholder.typicode.com/photos");
		
		JSONTokener jtk = new JSONTokener(jsonUrl.openStream());
		JSONArray jsonArr = new JSONArray(jtk);
		for(int i=0; i<jsonArr.length(); i++) {
			JSONObject jsonObj = jsonArr.getJSONObject(i);
			//System.out.println(jsonObj.toString(1));
			String thumbnailUrl = jsonObj.getString("thumbnailUrl");
			System.out.println(thumbnailUrl);
		}
	}

}
