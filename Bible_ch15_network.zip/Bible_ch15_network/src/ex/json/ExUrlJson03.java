package ex.json;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Label;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class ExUrlJson03 extends JFrame implements Runnable {
	private List<ImageIcon> imgIconList = new ArrayList();
	private List<JLabel> labelList = new ArrayList();
	JSONArray jsonArr;
	public static final int SIZE = 16;

	JPanel northPane = new JPanel();
	JPanel centerPane = new JPanel(new GridLayout(4, 4, 5, 5));
	JLabel statusLbl = new JLabel("status ... ");
	Container contentPane;

	{
		for (int i = 0; i<SIZE; i++) {
			ImageIcon icon = new ImageIcon();
			imgIconList.add(icon);
			labelList.add(new JLabel(icon));
		}
	}

	public void loadThumbnailUrlList(String urlPath) {
		statusLbl.setText("loadThumbnailUrlList");
		try {
			URL jsonUrl = new URL(urlPath);
			JSONTokener jtk = null;
			try {
				jtk = new JSONTokener(jsonUrl.openStream());
			} catch (Exception e) {
				System.out.println("Connection refused!");
				System.out.println("서버 연결이 끊겨 있습니다!");
				System.out.println("프로세스를 강제 종료합니다!");
				dispose();
				System.exit(0);
			}
			jsonArr = new JSONArray(jtk);
			imgIconList = new ArrayList();
			for (int i = 0; i<SIZE; i++) {
				JSONObject jsonObj = jsonArr.getJSONObject(i);
				String thumbnailUrl = jsonObj.getString("thumbnailUrl");
				
				String imgFilePath = thumbnailUrl.substring(thumbnailUrl.lastIndexOf("/"));
				System.out.println(imgFilePath);
				File dir = new File("thumbnail");
				if(!dir.exists()) {
					if(dir.mkdir()) {
						System.out.println("새 디렉토리를 생성 했습니다!");
					}
				}
				File file = new File(dir + imgFilePath);
				if(!file.exists()) {
					URL imgUrl = new URL(thumbnailUrl);
					URLConnection urlConn = imgUrl.openConnection();
					InputStream is = urlConn.getInputStream();
					DataInputStream dis = new DataInputStream(is);
					OutputStream os = new FileOutputStream(file);
					DataOutputStream dos = new DataOutputStream(os);
					int data=0;
					while((data = dis.read())!=-1) {
						dos.write(data);
					}
					statusLbl.setText("이미지 로딩 중 : " + thumbnailUrl);
				}
				imgIconList.add(new ImageIcon(file.getPath()));
				labelList.get(i).setIcon(imgIconList.get(i));
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ExUrlJson03() {
		contentPane = getContentPane();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(800, 600);
		
		contentPane.add(BorderLayout.NORTH, northPane);
		northPane.add(statusLbl);

		contentPane.add(new JScrollPane(centerPane));
		for (int i = 0; i<SIZE; i++) {
			centerPane.add(labelList.get(i));
		}
		statusLbl.setText("main end!!");
		
		// SWING 프레임에 콤포넌트를 모두 그린 후 이미지를 로드 한다.
		// 이미지를 로드하면서 콤포넌트를 붙여 나가는것은 바로 가능 하지 않다.
		new Thread(this).start();
	}

	public static void main(String[] args) {
		new ExUrlJson03().setVisible(true);
	} 

	@Override
	public void run() {
		// tomcat9를 이용해서 local에 서버를 구축하고 .json 파일을 로드 한다.
		loadThumbnailUrlList("http://localhost:8080/Server_resource/photos.json");
		statusLbl.setText("Finish loading!");
	}
}
