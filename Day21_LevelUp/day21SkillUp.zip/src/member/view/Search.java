package member.view;

public class Search extends MemberView {

	@Override
	public boolean onCreate() {
		System.out.println(titleSearch);

		return false;
	}

}
