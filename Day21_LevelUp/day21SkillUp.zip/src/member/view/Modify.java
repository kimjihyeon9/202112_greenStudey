package member.view;

public class Modify extends MemberView {

	@Override
	public boolean onCreate() {
		System.out.println(titleModify);

		return false;
	}

}
