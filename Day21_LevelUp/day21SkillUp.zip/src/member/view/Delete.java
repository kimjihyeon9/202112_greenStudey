package member.view;

public class Delete extends MemberView {
	@Override
	public boolean onCreate() {
		System.out.println(titleDelete);

		
		return false;
	}
}
