package member.view;

public class List extends MemberView {
	@Override
	public boolean onCreate() {
		System.out.println(titleList);
		
		
		return false;
	}
}
