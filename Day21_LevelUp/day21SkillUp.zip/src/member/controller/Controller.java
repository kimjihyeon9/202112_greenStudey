package member.controller;

import member.resource.R;
import member.view.MemberView;

public abstract class Controller extends R{
	public abstract MemberView hadleRequest();

}
