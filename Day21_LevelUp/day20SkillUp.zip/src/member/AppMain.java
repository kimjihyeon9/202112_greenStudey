package member;

import member.controller.DispatcherController;

public class AppMain {

	public static void main(String[] args) {
		DispatcherController.run();		
	}

}
