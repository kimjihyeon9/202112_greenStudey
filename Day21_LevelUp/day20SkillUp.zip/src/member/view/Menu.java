package member.view;

public class Menu extends MemberView {

	@Override
	public void onCreate() {
		System.out.println(titleMenu);
	}
	
}
