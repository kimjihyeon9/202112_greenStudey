package member.view;

public class Delete extends MemberView {

	@Override
	public void onCreate() {
		System.out.println(titleDelete);
	}
	
}
