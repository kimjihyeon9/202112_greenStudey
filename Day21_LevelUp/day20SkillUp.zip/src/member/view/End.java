package member.view;

public class End extends MemberView {

	@Override
	public void onCreate() {
		System.out.println(titleEnd);
	}
	
}
