package member.view;

public class List extends MemberView {

	@Override
	public void onCreate() {
		System.out.println(titleList);
	}

}
