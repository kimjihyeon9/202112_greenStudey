package Address_view;

import Address.R;

public class AddressDatail extends AddrView {

	@Override
	public void display() {
		System.out.println(R.addressvo);
	}

}
