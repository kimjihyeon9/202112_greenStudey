package Address;

import Address_view.AddrView;

public class ViewContainer {
	public void run(AddrView view) {
		view.display();
	}
}
