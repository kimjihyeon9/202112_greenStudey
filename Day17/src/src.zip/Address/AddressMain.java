package Address;

import java.io.IOException;

public class AddressMain {
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		System.out.println("-------------------------- 프로그램 --------------------------");
		R.addressController.run();
	}

}
