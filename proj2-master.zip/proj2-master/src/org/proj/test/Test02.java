//package org.proj.test;
//
//import static org.proj.Resource.FRAME_HEIGHT;
//import static org.proj.Resource.FRAME_WIDTH;
//import static org.proj.Resource.LoginView;
//
//import java.awt.BorderLayout;
//import java.awt.Container;
//
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//
//import javafx.embed.swing.JFXPanel;
//
//
//class CenterPane extends JPanel{
//	
//	JFXPanel pnCenter = new JFXPanel();
//	
//	
//}
//
//
//public class Test02 extends JFrame {
//	Container contentPane;
//
//	public Test02() {
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
//		contentPane = getContentPane();
////		contentPane.setLayout(null);
//		
//		CenterPane cp = new CenterPane();
//		this.add(cp,BorderLayout.CENTER);
//		this.setVisible(true);
//	}
//	
//	public static void main(String[] args) {
//		new Test02();
//	}
//}
