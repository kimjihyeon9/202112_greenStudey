package org.proj.model;

import java.io.Serializable;

public class UserDto implements Serializable {
//	private static final long serialVersionUID = 1L;
	
	private int no;
	private String name;
	private String id;
	private String password;
	private int age;
	
	public UserDto() {
		this(0,"","","",0);
	}
	
	public UserDto(int no, String name, String id, String password, int age) {
		this.no = no;
		this.name =name;
		this.id = id;
		this.password = password;
		this.age = age;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDto other = (UserDto) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return no + "\t" + name + "\t" + id + "\t" + age;
	}

//	@Override
//	public void writeExternal(ObjectOutput out) throws IOException {
//		out.writeUTF(name);
//		out.writeUTF(id);
//		out.writeUTF(password);
//		out.write(age);
//	}
//
//	@Override
//	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
//		no = in.read();
//		name = in.readUTF();
//		id = in.readUTF();
//		password = in.readUTF();
//		age = in.read();
//	}
	
	
	

}
