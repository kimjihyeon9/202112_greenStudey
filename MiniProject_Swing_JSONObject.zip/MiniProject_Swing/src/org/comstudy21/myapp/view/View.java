package org.comstudy21.myapp.view;

import javax.swing.JPanel;

import org.comstudy21.myapp.resource.R;

public abstract class View extends JPanel implements R {
	public abstract void display();
}
