package org.comstudy21.myapp.evt;

import java.awt.event.KeyAdapter;

public class KeyEvtHandler extends KeyAdapter {

}
