package org.comstudy21.game;

public interface Game {
	void play();
}
